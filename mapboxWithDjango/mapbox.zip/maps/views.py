from django.shortcuts import render


def default_map(request):
    # return render(request, 'default.html', {})
    # TODO: move this token to Django settings from an environment variable
    # found in the Mapbox account settings and getting started instructions
    # see https://www.mapbox.com/account/ under the "Access tokens" section
    mapbox_access_token = 'pk.eyJ1IjoibG9naXN0ZXgiLCJhIjoiY2s3NjR3dng0MTJlODNkbnZvMGRydml5ZiJ9.jKqu8ijVAYqt0cqFGq-JhQ'
    return render(request, 'default.html',
                  { 'mapbox_access_token': mapbox_access_token })
