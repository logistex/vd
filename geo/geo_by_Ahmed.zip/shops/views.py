from django.views import generic
from django.contrib.gis.geos import fromstr
from django.contrib.gis.db.models.functions import Distance
from .models import Shop
from django.contrib.gis.geos import Point

# 한양여대 정보문화관 좌표
longitude = 127.049046
latitude = 37.558649
# 서울시청 좌표
longitude =126.978546
latitude = 37.570377

user_location = Point(longitude, latitude, srid=4326)


class ShopList(generic.ListView):
    model = Shop
    context_object_name = 'shops'
    queryset = Shop.objects \
        .exclude(name='no-name') \
        .annotate(distance=Distance('location', user_location)) \
        .order_by('distance')[0:30]
    template_name = 'shops/index.html'
